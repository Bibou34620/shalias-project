#ifndef FILES_HPP_INCLUDED
#define FILES_HPP_INCLUDED

#include <fstream>

//N'en parlons pas...
using namespace std;

//Fichiers
fstream list_of_aliases("./aliases_created/list_of_aliases.txt", ios::app);
fstream modifyBashrc;
ifstream list_of_aliases_reading("./aliases_created/list_of_aliases.txt", ios::app);

#endif // FILES_HPP_INCLUDED
