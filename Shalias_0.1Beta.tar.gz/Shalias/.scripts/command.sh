echo alias custom="alias" >> ~/.bashrc
echo alias uncustom="unalias" >> ~/.bashrc

