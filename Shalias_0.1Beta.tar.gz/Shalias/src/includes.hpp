#ifndef INCLUDES_HPP_INCLUDED
#define INCLUDES_HPP_INCLUDED

//Includes
#include <iostream>
#include <unistd.h>
#include <fstream>
#include <string>
#include <ncurses.h>

#endif // INCLUDES_HPP_INCLUDED
