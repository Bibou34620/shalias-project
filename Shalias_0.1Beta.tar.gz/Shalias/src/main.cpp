#include "includes.hpp"
#include "global_variables.hpp"
#include "files.hpp"

//Namespaces
using namespace std;


//Protos
void selection();
int addCommand();
void rmCommand();

//Fonction principale
int main()
{
    //Si c'est la première fois qu'on utilise
    system("cd .scripts; ./command.sh");
    system("cd .scripts; rm -rf command.sh");


    //A partir de la fonction selection() les autres fonctions vont se lancer
    selection();
}

//Fnctn pour faire le choix
void selection()
{
    cout << "Shalias is starting..." << endl;
    sleep(2);
    //Récuperer le nom utilisateur linux
    cout << "Enter your linux username" << endl;
    cout << "If you don't know your linux username it's that:" << endl;
    system("whoami");
    cin >> username;
    //Séléctionner un mode
    cout << "Select a mode" << endl;
    cout << "1) Add custom command" << endl;
    cout << "2) Remove custom command" << endl;

    //Demande du choix
    cin >> number;

    while (true)
    {
        //Si nombre == 1 ...
        if(number == 1)
        {
            cout << "Console mode is starting" << endl;
            //On va dans la fnctn consoleMode()
            addCommand();
            break;
        }

        //Si alors nombre == 2...
        else if(number == 2)
        {
            //On va dans la fnctn unalias()
            rmCommand();
            break;
        }

    }




}

//Fnctn pour ajouter une commande customisée
int addCommand()
{
    modifyBashrc.open("/home/" + username + "/.bashrc", ios::app);
    //Si le fichier modifyBashrc est trouvé...
    if(modifyBashrc)
    {
        //On écrit que ca paut être édité
        cout << "The bash config file can be edited !" << endl;

        //Répéter indéfiniment
        while (true)
        {
            system("clear");
            //On demande d'entrer une commande personnalisée
            cout << "Enter a command for your custom command(example: c)" << endl;

            cin >> nameForCommand;

            //On demande d'entrer la commande par défaut
            cout << "Enter the command by default (example: clear)" << endl;

            cin >> commandByDefault;


            //On demande d'entrer un commentaire pour retrouver plus facilement la commande
            cout << "If you wish, you can add a comment to find your command more easily the list of custom commands created (DON'T ENTER SPACES !!)" << endl;

            cin >> comment;


            //On entre la commande personnalisée dans le fichier bashrc
            modifyBashrc << "custom " + nameForCommand + "=" + commandByDefault;

            //Si le fichier list_of_aliases est trouvé...
            if(list_of_aliases)
            {
                string isFileVoid;
                //On écrit la commande avec le commentaire dans le fichier
                getline(list_of_aliases_reading, isFileVoid);

                cout << isFileVoid;





                list_of_aliases << "custom " + nameForCommand + "=" + commandByDefault + "      #" + comment + "\n";








            }

            //Sinon...
            else
            {
                //On écrit un message d'erreur
                cout << "List of aliases not found !" << endl;
            }

            //On explique qu'il faut redémarrer le terminal et un exemple de commande
            cout << "You can now restart your terminal or made a new custom command !" << endl;
            cout << "An example for my new command: c=clear when i will write c it will clear the console" << endl;


            //On demande si on veut refaire un alias ou quitter
            cout << "Do you want to quit? [y/n]" << endl;

            cin >> refaire;


            //Si refaire == "n"
            if(refaire == "n")
            {
                //On refait un alias
                continue;
            }

            //Si refaire == "y"
            else if(refaire == "y")
            {
                //On quitte
                cout << "Quit..." << endl;
                break;
            }


        }
    }


    //Si le fichier bashrc n'est pas trouvé
    else
    {
        //Message d'erreur
        cout << "Bash config file not found !" << endl;
        //On retourne 1 en signe d'erreur
        return 1;
    }
}

//Fnctn pour enlever une commande personnalisée
void rmCommand()
{
    modifyBashrc.open("/home/" + username + "/.bashrc", ios::app);
    //On explique la fonctionnalité du menu
    cout << "With this menu, you can delete the custom commands you have already created" << endl;

    //2 choix
    cout << "1) View all the custom commands created" << endl;
    cout << "2) Remove a custom command (If you don't know the name of the command you want to delete, press 1 to see the list)" << endl;

    //Input du choix
    cin >> choice;

    //Si choix == 1...
    if(choice == 1)
    {
        //On récupère autant de fois qu'il faut ce qu'il faut afficher
        while(getalias)
        {
            string getfile;
            getline(list_of_aliases_reading, getfile);

            //Si la ligne obtenue == 0
            if(getfile.length() == 0)
            {
                //On vérifie quand même une deuxième fois (au cas ou si il y a des espaces)
                if(getfile.length() == 0)
                {
                    //On peut estimer que l'on peut arrêter de récupèrer
                    getalias == false;
                    break;
                }

                else
                {
                    cout << getfile << endl;
                }

            }

            //Sinon...
            else
            {
                //On continue a afficher dans la console
                cout << getfile << endl;
            }

        }

        //On demande quelle commande veut-on effacer ?
        cout << "Now, which custom command do you want do delete ?" << endl;
        cout << "Enter the name of the custom command: ";

        //Input de la commande a effacer
        cin >> command_to_erase;

        //Effacer la commande personnalisée
        modifyBashrc << "\nuncustom " + command_to_erase;

        //C'est bon !
        cout << "Done ! Now, nano editor will be open to remove your custom command in the list (delete only the command you entered (for more help visite https://website.com))" << endl;
        cout << "Wait 3 seconds..." << endl;
        sleep(3);
        system("nano ./aliases_created/list_of_aliases.txt");
        cout << "Restart your terminal and the custom command will don't appair again" << endl;

    }

    //Si choix == 2...
    if(choice == 2)
    {
        cout << "Enter the name of the custom command you want to erase: ";

        //Input de la commande à effacer
        cin >> command_to_erase;

        //Effacer la commande personnalisée
        modifyBashrc << "\nuncustom " + command_to_erase;

        //C'est bon !
        system("clear");
        cout << "Done ! Now, nano editor will be open to remove your custom command in the list (delete only the command you entered (for more help visite https://shalias.com))" << endl;
        cout << "Wait 3 seconds..." << endl;
        sleep(3);
        system("nano ./aliases_created/list_of_aliases.txt");
        cout << "Restart your terminal and the custom command will don't appair again" << endl;
    }
}






