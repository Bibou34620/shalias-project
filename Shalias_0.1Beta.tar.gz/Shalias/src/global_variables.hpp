#ifndef GLOBAL_VARIABLES_HPP_INCLUDED
#define GLOBAL_VARIABLES_HPP_INCLUDED

#include <string>

//Variables globales
int choice;
int number;
std::string txt;
bool getalias = true;
std::string ok;
std::string command_to_erase;
std::string nameForCommand;
std::string commandByDefault;
std::string comment;
std::string refaire;
std::string username;

#endif // GLOBAL_VARIABLES_HPP_INCLUDED
